package com.qsp.student_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
